
      <form name="formBusqueda" action="../controller/buscarNombre.php" method="POST">

          <table>
              <tr>
                  <td>Nombre del alimento:</td>
                 <td>
       <input type="text" name="nombre"
              value="">
              ('%' como comodín)
     </td>

                  <td>
       <input type="submit" name="buscar" value="Buscar">
     </td>
              </tr>
          </table>

          </table>

      </form>

      <table>
         <tr>
             <th>alimento (por 100g)</th>
             <th>energía (Kcal)</th>
             <th>grasa (g)</th>
         </tr>
             <tr>
                 <td>  </td>
                 <td>  </td>
                 <td>  </td>
             </tr>

     </table>
