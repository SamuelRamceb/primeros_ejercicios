 <table>
     <tr>
         <th>alimento (por 100g)</th>
         <th>energía (Kcal)</th>
         <th>grasa (g)</th>
     </tr>
     <tr>
         <?php
         include('../controller/main.php');
         mostrarAlimento();
         ?>
     </tr>

 </table>


