
      <form name="formBusqueda" action="../controller/buscarId.php" method="POST">

<table>
    <tr>
        <td>Codigo del alimento:</td>
       <td>
<input type="number" name="id"
    value="" required>
</td>

        <td>
<input type="submit" name="buscar" value="Buscar">
</td>
    </tr>
</table>

</table>

</form>

<table>
<tr>
   <th>alimento (por 100g)</th>
   <th>energía (Kcal)</th>
   <th>grasa (g)</th>
</tr>
   <tr>
       <td>  </td>
       <td>  </td>
       <td>  </td>
   </tr>

</table>
