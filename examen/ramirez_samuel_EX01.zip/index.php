<?php

include('./paraAlumno/controller/main.php');
main();

?>